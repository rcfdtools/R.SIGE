# Grillas ráster

\grid: carpeta para el almacenamiento de los mapas ráster. Almacenar en este contenedor, archivos tipo GeoTIFF (.tif), GRID de Esri, Ascii (.asc) y demás asociados. 

> Utilice la carpeta `\dem` para almacenar los modelos digitales de elevación en formato GeoTIFF, ascii, grid, ecw.

