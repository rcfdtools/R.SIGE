#  Referencias generales

`\ref`: carpeta para el almacenamiento de documentos de referencias bibliográficas, incluidos libros de uso libre, artículos e informes técnicos recopilados.

