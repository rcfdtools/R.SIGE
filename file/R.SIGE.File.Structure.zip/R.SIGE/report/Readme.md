# Reportes técnicos

`\report`: carpeta para el almacenamiento de reportes e informes técnicos de avance de proyecto en formato Microsoft Word y Adobe Acrobat.

> En cada avance se debe crear una carpeta de Anexos que incluye los mapas producidos en formato .pdf y subinformes detallados de análisis.