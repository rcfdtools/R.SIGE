# Código fuente - Sourcecode

`\src`: carpeta para el almacenamiento de scripts en python y otros lenguajes. Utilice también este directorio para el almacenamiento de los libros creados mediante Jupyter de Anaconda.

