# Layer style & layer setup

`\lyr`: carpeta para el almacenamiento de los archivos de configuración de capa y archivos de estilos de visualización.